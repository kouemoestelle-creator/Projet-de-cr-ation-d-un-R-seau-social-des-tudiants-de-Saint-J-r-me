import { Router } from 'express';
import { query } from '../db.js';
import { HttpError, ah } from '../utils/errors.js';
import { cleanText, parseId } from '../utils/validate.js';
import { POST_SELECT, mapPost } from '../utils/mappers.js';
import { requireAuth } from '../middleware/auth.js';
import { uploadImage, saveImage, removeImage } from '../middleware/upload.js';

const router = Router();
router.use(requireAuth);

const MAX_BODY = 2000;

// Fil d'actualité chronologique, du plus récent au plus ancien (F9).
// ?before=<id du dernier post reçu> pour charger la suite ; ?author=<id> pour les publications d'un étudiant.
router.get(
  '/',
  ah(async (req, res) => {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const before = req.query.before ? parseId(req.query.before) : null;
    const author = req.query.author ? parseId(req.query.author) : null;

    const { rows } = await query(
      `${POST_SELECT}
       WHERE p.status = 'visible' AND u.status = 'active'
         AND ($1::int IS NULL OR p.id < $1)
         AND ($2::int IS NULL OR p.author_id = $2)
       ORDER BY p.id DESC
       LIMIT $3`,
      [before, author, limit + 1]
    );
    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);
    res.json({ posts: page.map(mapPost), nextCursor: hasMore ? page[page.length - 1].id : null });
  })
);

// Créer une publication : texte et/ou image (F8)
router.post(
  '/',
  uploadImage('image'),
  ah(async (req, res) => {
    const body = cleanText(req.body?.body, { max: MAX_BODY, field: 'Le texte' });
    if (!body && !req.file) throw new HttpError(400, 'Écrivez un texte ou ajoutez une image.');
    const image = req.file ? await saveImage(req.file) : null;
    const { rows } = await query('INSERT INTO posts (author_id, body, image_path) VALUES ($1, $2, $3) RETURNING id', [
      req.user.id,
      body,
      image,
    ]);
    const full = await query(`${POST_SELECT} WHERE p.id = $1`, [rows[0].id]);
    res.status(201).json({ post: mapPost(full.rows[0]) });
  })
);

// Modifier le texte de sa propre publication
router.patch(
  '/:id',
  ah(async (req, res) => {
    const id = parseId(req.params.id);
    const { rows } = await query(`SELECT * FROM posts WHERE id = $1 AND status = 'visible'`, [id]);
    const post = rows[0];
    if (!post) throw new HttpError(404, 'Publication introuvable.');
    if (post.author_id !== req.user.id) throw new HttpError(403, 'Vous ne pouvez modifier que vos publications.');
    const body = cleanText(req.body?.body, { max: MAX_BODY, field: 'Le texte' });
    if (!body && !post.image_path) throw new HttpError(400, 'Une publication ne peut pas être vide.');
    await query('UPDATE posts SET body = $2, updated_at = now() WHERE id = $1', [id, body]);
    const full = await query(`${POST_SELECT} WHERE p.id = $1`, [id]);
    res.json({ post: mapPost(full.rows[0]) });
  })
);

// Supprimer : l'auteur, ou un modérateur / administrateur
router.delete(
  '/:id',
  ah(async (req, res) => {
    const id = parseId(req.params.id);
    const { rows } = await query('SELECT * FROM posts WHERE id = $1', [id]);
    const post = rows[0];
    if (!post) throw new HttpError(404, 'Publication introuvable.');
    const privileged = ['moderator', 'admin'].includes(req.user.role);
    if (post.author_id !== req.user.id && !privileged) {
      throw new HttpError(403, 'Vous ne pouvez supprimer que vos publications.');
    }
    await query('DELETE FROM posts WHERE id = $1', [id]);
    await removeImage(post.image_path);
    res.json({ ok: true });
  })
);

export default router;
