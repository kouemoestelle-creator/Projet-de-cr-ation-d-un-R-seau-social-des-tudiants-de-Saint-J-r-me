import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import Avatar from './Avatar.jsx';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/connexion', { replace: true });
  }

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <strong className="brand">Réseau Saint Jérôme</strong>
          <nav className="nav">
            <NavLink to="/" end>Fil</NavLink>
            <NavLink to="/profil">
              <Avatar name={user.displayName} photoUrl={user.photoUrl} size={24} /> Profil
            </NavLink>
            <button type="button" className="link-button" onClick={handleLogout}>Déconnexion</button>
          </nav>
        </div>
      </header>
      <main className="container">
        <Outlet />
      </main>
    </>
  );
}
