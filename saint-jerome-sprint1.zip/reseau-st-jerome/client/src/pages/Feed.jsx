import { useEffect, useState } from 'react';
import { api } from '../api.js';
import Composer from '../components/Composer.jsx';
import PostList from '../components/PostList.jsx';

export default function Feed() {
  const [posts, setPosts] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load(before = null) {
    setError('');
    try {
      const data = await api(`/posts?limit=20${before ? `&before=${before}` : ''}`);
      setPosts((list) => (before ? [...list, ...data.posts] : data.posts));
      setCursor(data.nextCursor);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <>
      <Composer onCreated={(post) => setPosts((list) => [post, ...list])} />
      {loading && <p className="muted center">Chargement du fil…</p>}
      {error && (
        <p className="error center" role="alert">
          {error} <button className="link-button" onClick={() => load()}>Réessayer</button>
        </p>
      )}
      {!loading && <PostList posts={posts} setPosts={setPosts} />}
      {cursor && (
        <button className="btn btn-light block" onClick={() => load(cursor)}>Voir les publications plus anciennes</button>
      )}
    </>
  );
}
