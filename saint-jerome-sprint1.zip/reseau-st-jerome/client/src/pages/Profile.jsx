import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import Avatar from '../components/Avatar.jsx';
import PostList from '../components/PostList.jsx';
import { compressImage } from '../utils/compressImage.js';

export default function Profile() {
  const { id } = useParams();
  const { user: me, setUser } = useAuth();
  const targetId = id ? Number(id) : me.id;
  const own = targetId === me.id;

  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ displayName: '', filiere: '', niveau: '', bio: '' });
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const photoInput = useRef(null);

  const shown = own ? me : profile?.user;

  useEffect(() => {
    let cancelled = false;
    setError('');
    setEditing(false);
    setMessage('');
    api(`/users/${targetId}`)
      .then((d) => !cancelled && setProfile(d))
      .catch((err) => !cancelled && setError(err.message));
    api(`/posts?author=${targetId}&limit=50`)
      .then((d) => !cancelled && setPosts(d.posts))
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [targetId]);

  function startEdit() {
    setForm({
      displayName: me.displayName || '',
      filiere: me.filiere || '',
      niveau: me.niveau || '',
      bio: me.bio || '',
    });
    setMessage('');
    setEditing(true);
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const data = await api('/users/me', { method: 'PATCH', body: form });
      setUser(data.user);
      setEditing(false);
      setMessage('Profil enregistré.');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function changePhoto(e) {
    const chosen = e.target.files?.[0];
    e.target.value = '';
    if (!chosen) return;
    setBusy(true);
    setError('');
    try {
      const small = await compressImage(chosen, { maxSize: 512, quality: 0.85 });
      const formData = new FormData();
      formData.append('photo', small);
      const data = await api('/users/me/photo', { method: 'POST', formData });
      setUser(data.user);
      setMessage('Photo mise à jour.');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  if (!shown) {
    return error ? <p className="error center" role="alert">{error}</p> : <p className="muted center">Chargement…</p>;
  }

  return (
    <>
      <section className="card profile">
        <div className="row">
          <Avatar name={shown.displayName} photoUrl={shown.photoUrl} size={72} />
          <div className="grow">
            <h1>{shown.displayName}</h1>
            <p className="muted">{[shown.filiere, shown.niveau].filter(Boolean).join(' · ') || 'Filière non renseignée'}</p>
          </div>
        </div>
        {shown.bio && !editing && <p className="body">{shown.bio}</p>}
        {own && !editing && (
          <div className="row">
            <button className="btn btn-light" onClick={startEdit}>Modifier mon profil</button>
            <input ref={photoInput} type="file" accept="image/jpeg,image/png" onChange={changePhoto} hidden />
            <button className="btn btn-light" onClick={() => photoInput.current.click()} disabled={busy}>Changer la photo</button>
          </div>
        )}
        {own && editing && (
          <form className="form" onSubmit={save}>
            <label>Nom affiché<input value={form.displayName} onChange={set('displayName')} minLength={2} maxLength={80} required /></label>
            <label>Filière<input value={form.filiere} onChange={set('filiere')} maxLength={80} /></label>
            <label>Niveau<input value={form.niveau} onChange={set('niveau')} maxLength={40} /></label>
            <label>Biographie<textarea value={form.bio} onChange={set('bio')} maxLength={300} rows={3} /></label>
            <div className="row">
              <button className="btn" disabled={busy}>Enregistrer</button>
              <button type="button" className="btn btn-light" onClick={() => setEditing(false)}>Annuler</button>
            </div>
          </form>
        )}
        {message && <p className="success">{message}</p>}
        {error && <p className="error" role="alert">{error}</p>}
      </section>

      <h2 className="section-title">Publications</h2>
      <PostList posts={posts} setPosts={setPosts} />
    </>
  );
}
